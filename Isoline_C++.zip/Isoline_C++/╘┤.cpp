#include <osgViewer/Viewer>
#include <osgDB/ReadFile>

//#include"DEMLineShow.h"
#include <opencv2/highgui.hpp>  
#include <opencv2/core.hpp>  

#include<vector>
#include<iostream>
#include<fstream>
#include<string>

#include <osgViewer/Viewer>
#include <osgDB/ReadFile>
#include <osg/Texture2D>
#include <osg/ShapeDrawable>
#include<osg/LineWidth>

using namespace cv;
using namespace std;

class PtLoc {
public:
	double X;
	double Y;
	double Z;
	int in;//the number of entered grid
	int col;
	int row;//
	int HK;//0 stands for horizontal edge��1 stands for vertical edge
};


class CLine {
public:
	std::vector<PtLoc> pt;
	int shape = 0;//0 when it's open curve��1 stands for closed curve
};


class DEM
{
public:
	DEM(std::string path);   
	~DEM();

	std::vector<std::vector<double>> GetNearestHeight();//get rid of none value points
	osg::Node* Create_DEM(std::string dem_path); //for isoline visualization

	std::vector<std::vector<double>> StateMatHk(double zk);
	std::vector<std::vector<double>> StateMatVk(double zk);

	void GetlinePt(std::vector<std::vector<double>>& Hk, std::vector<std::vector<double>>& Vk, double Z, int ni, int nj, CLine& line);
	void getline(std::vector<std::vector<double>> Hk, std::vector<std::vector<double>> Vk, double Z, std::vector<CLine>& Line);
	void savelines(std::string dir, std::vector<std::vector<CLine>> Line);
	void nlines(std::string dir, double dz);



private:
	std::vector<std::vector<double>> height_mat;   //store height value
	std::vector<std::pair<int, int>> invalid_val; //DEM nodata value
	std::vector<std::vector<CLine>> AllLines;//Store all isolines

	int col;
	int row;
	double A;
	double X0, Y0;    //start point, the left bottom corner of the image     
	double dx, dy;    //dem resolution

	double max_z, min_z;

	double delz;	//Set contour interval
	int image_col, image_row;

};


#define START_X_IMAGE 0
#define START_Y_IMAGE 0
#define DX_IMAGE 1
#define DY_IMAGE 1


DEM::DEM(string path)
{
	
	fstream f(path);
	f >> X0 >> Y0 >> A >> dx >> dy >> col >> row;
	
	
	max_z = 0;
	min_z = INT_MAX;

	for (int i = 0; i < row; i++)
	{
		vector<double> temp;
		for (int j = 0; j < col; j++)
		{
			double temp_z;
			f>>temp_z ;
			if (temp_z < -9999)
			{
				temp.push_back(temp_z);
				invalid_val.push_back(make_pair(i, j));
				continue;
			}
			max_z = max(temp_z, max_z);
			min_z = min(temp_z, min_z);
			temp.push_back(temp_z + 1e-5);
		}
		height_mat.push_back(temp);
	}
    //the isoline should be higher than the lowest value and lower than the highest value
	max_z = int(max_z);
	min_z = int(min_z) + 1;

	height_mat = GetNearestHeight();
}

DEM::~DEM()
{
	height_mat.clear();
}


vector<vector<double>> DEM::GetNearestHeight() {

	vector<vector<double>> mat = height_mat;

	for (int i = 0; i < invalid_val.size(); i++)
	{
		int temp_row = invalid_val[i].first;
		int temp_col = invalid_val[i].second;
		int search_row = temp_row;
		int search_col = temp_col;   //beginning position of searching

		//from left-upper corner
		if (temp_row <= row / 2 && temp_col <= col / 2)
		{
			while (search_col < col)  //search along every row
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_col++;
			}
			if (search_col != col) continue;
			search_col = temp_col;
			while (search_row < row)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_row++;
			}

		}
		//from right-upper corner
		else if (temp_row <= row / 2 && temp_col > col / 2)
		{
			while (search_col >= 0)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_col--;
			}
			if (search_col != col) continue;
			search_col = temp_col;
			while (search_row < row)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_row++;
			}
		}

		//from left-bottom corner
		else if (temp_row > row / 2 && temp_col <= col / 2)
		{
			while (search_col < col) 
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_col++;
			}
			if (search_col != col) continue;
			search_col = temp_col;
			while (search_row >= 0)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_row--;
			}
		}

		//from right-upper corner
		else if (temp_row > row / 2 && temp_col > col / 2)
		{
			while (search_col >= 0)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_col--;
			}
			if (search_col != col) continue;
			search_col = temp_col;
			while (search_row < row)
			{
				if (mat[search_row][search_col] > -9999)
				{
					mat[temp_row][temp_col] = mat[search_row][search_col];
					break;
				}
				search_row++;
			}
		}
	}

	return mat;
}

vector<vector<double>> DEM::StateMatHk(double zk) {
	//find the maximum and minimum height value

	double z_min, z_max;
	z_min = min_z;
	z_max = max_z;

	std::vector<std::vector<double>> Hk;

	for (int i = 0; i < row - 1; i++)//For Hk matrix, subtract between two columns��row minus 1
	{
		vector<double> temp;
		for (int j = 0; j < col; j++)
		{
			double temph;
			if (height_mat[i][j] > 0 && height_mat[i + 1][j] > 0 && (height_mat[i][j] - zk) * (height_mat[i + 1][j] - zk) < 0)
				temph = 1;
			else temph = 0;
			temp.push_back(temph);
		}
		Hk.push_back(temp);
	}
	//cout << "The" << t << "-eth contour line has been extracted." << "Hk Matrix calculation is Done." << endl;
	return Hk;
}

vector<vector<double>> DEM::StateMatVk(double zk) {


	double z_min, z_max;
	z_min = min_z;
	z_max = max_z;
	std::vector<std::vector<double>> Vk;

	for (int i = 0; i < row; i++)
	{
		vector<double> temp;
		for (int j = 0; j < col - 1; j++)//Vk���������col��1
		{
			double temph;
			if (height_mat[i][j] > 0 && height_mat[i][j + 1] > 0 && (height_mat[i][j] - zk) * (height_mat[i][j + 1] - zk) < 0)
				temph = 1;
			else temph = 0;
			temp.push_back(temph);
		}
		Vk.push_back(temp);
	}

	return Vk;
}

void DEM::GetlinePt(vector<vector<double>>& Hk, vector<vector<double>>& Vk, double Z, int ni, int nj, CLine& line)
{
	PtLoc pt;
	pt = line.pt[0];
	int count = 0;
	while (count != -1)
	{//˳ʱ���ж�
		if (pt.in == 4)
		{
			if (nj == col - 1 || Hk[ni][nj + 1] + Vk[ni][nj] + Vk[ni + 1][nj] == 0)
				break;
			if (Hk[ni][nj + 1] + Vk[ni][nj] + Vk[ni + 1][nj] == 3)
			{
				double zmean = (height_mat[ni][nj] + height_mat[ni][nj + 1] + height_mat[ni + 1][nj] + height_mat[ni + 1][nj + 1]) / 4.0;
				if ((height_mat[ni][nj] - Z) * (zmean - Z) < 0)
				{
					Vk[ni][nj] = 0;
					pt.in = 1;
					pt.X = X0 + nj * dx + (Z - height_mat[ni][nj]) / (height_mat[ni][nj + 1] - height_mat[ni][nj]) * dx;
					pt.Y = Y0 + ni * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni;
					pt.col = nj;
					line.pt.push_back(pt);
				}
				else
				{
					Vk[ni + 1][nj] = 0;
					pt.in = 3;
					pt.X = X0 + nj * dx + (Z - height_mat[ni + 1][nj]) / (height_mat[ni + 1][nj + 1] - height_mat[ni + 1][nj]) * dx;
					pt.Y = Y0 + (ni + 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni + 1;
					pt.col = nj;
					line.pt.push_back(pt);
					ni += 1;
				}
			}
			else
			{
				if (Vk[ni][nj] == 1)
				{
					pt.in = 1;
					pt.X = X0 + nj * dx + (Z - height_mat[ni][nj]) / (height_mat[ni][nj + 1] - height_mat[ni][nj]) * dx;
					pt.Y = Y0 + ni * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni;
					pt.col = nj;
					line.pt.push_back(pt);
					Vk[ni][nj] = 0;

				}
				else if (Hk[ni][nj + 1] == 1)
				{
					pt.in = 4;
					pt.X = X0 + (nj + 1) * dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj + 1]) / (height_mat[ni + 1][nj + 1] - height_mat[ni][nj + 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj + 1;
					line.pt.push_back(pt);
					Hk[ni][nj + 1] = 0;
					nj += 1;
				}
				else if (Vk[ni + 1][nj] == 1)
				{
					pt.in = 3;
					pt.X = X0 + nj * dx + (Z - height_mat[ni + 1][nj]) / (height_mat[ni + 1][nj + 1] - height_mat[ni + 1][nj]) * dx;
					pt.Y = Y0 + (ni + 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni + 1;
					pt.col = nj;
					line.pt.push_back(pt);
					Vk[ni + 1][nj] = 0;
					ni += 1;
				}

			}
		}
		else if (pt.in == 3)
		{
			if (ni == row - 1 || Hk[ni][nj] + Hk[ni][nj + 1] + Vk[ni + 1][nj] == 0)
				break;
			if (Hk[ni][nj] + Hk[ni][nj + 1] + Vk[ni + 1][nj] == 3)
			{
				double zmean = (height_mat[ni][nj] + height_mat[ni][nj + 1] + height_mat[ni + 1][nj] + height_mat[ni + 1][nj + 1]) / 4.0;
				if ((height_mat[ni][nj + 1] - Z) * (zmean - Z) < 0)
				{
					pt.in = 4;
					pt.X = X0 + (nj + 1) * dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj + 1]) / (height_mat[ni + 1][nj + 1] - height_mat[ni][nj + 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj + 1;
					line.pt.push_back(pt);
					Hk[ni][nj + 1] = 0;
					nj += 1;
				}
				else
				{
					pt.in = 2;
					pt.X = X0 + (nj)*dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj]) / (height_mat[ni + 1][nj] - height_mat[ni][nj]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj;
					line.pt.push_back(pt);
					Hk[ni][nj] = 0;
				}
			}
			else
			{
				if (Hk[ni][nj + 1] == 1)
				{
					pt.in = 4;
					pt.X = X0 + (nj + 1) * dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj + 1]) / (height_mat[ni + 1][nj + 1] - height_mat[ni][nj + 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj + 1;
					line.pt.push_back(pt);
					Hk[ni][nj + 1] = 0;
					nj += 1;
				}
				else if (Vk[ni + 1][nj] == 1)
				{
					pt.in = 3;
					pt.X = X0 + nj * dx + (Z - height_mat[ni + 1][nj]) / (height_mat[ni + 1][nj + 1] - height_mat[ni + 1][nj]) * dx;
					pt.Y = Y0 + (ni + 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni + 1;
					pt.col = nj;
					line.pt.push_back(pt);
					Vk[ni + 1][nj] = 0;
					ni += 1;
				}
				else if (Hk[ni][nj] == 1)
				{
					pt.in = 2;
					pt.X = X0 + (nj)*dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj]) / (height_mat[ni + 1][nj] - height_mat[ni][nj]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj;
					line.pt.push_back(pt);
					Hk[ni][nj] = 0;

				}
			}

		}
		else if (pt.in == 2)
		{
			if (nj == 0 || Vk[ni + 1][nj - 1] + Hk[ni][nj - 1] + Vk[ni][nj - 1] == 0)
				break;
			if (Vk[ni + 1][nj - 1] + Hk[ni][nj - 1] + Vk[ni][nj - 1] == 3)
			{
				double zmean = (height_mat[ni][nj - 1] + height_mat[ni][nj] + height_mat[ni + 1][nj - 1] + height_mat[ni + 1][nj]) / 4.0;
				if ((height_mat[ni + 1][nj] - Z) * (zmean - Z) < 0)
				{
					pt.in = 3;
					pt.X = X0 + (nj - 1) * dx + (Z - height_mat[ni + 1][nj - 1]) / (height_mat[ni + 1][nj] - height_mat[ni + 1][nj - 1]) * dx;
					pt.Y = Y0 + (ni + 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni + 1;
					pt.col = nj - 1;
					line.pt.push_back(pt);
					Vk[ni + 1][nj - 1] = 0;
					ni += 1;
					nj -= 1;
				}
				else
				{
					pt.in = 1;
					pt.X = X0 + (nj - 1) * dx + (Z - height_mat[ni][nj - 1]) / (height_mat[ni][nj] - height_mat[ni][nj - 1]) * dx;
					pt.Y = Y0 + (ni)*dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni;
					pt.col = nj - 1;
					line.pt.push_back(pt);
					Vk[ni][nj - 1] = 0;
					nj -= 1;
				}
			}
			else
			{
				if (Vk[ni + 1][nj - 1] == 1)
				{
					pt.in = 3;
					pt.X = X0 + (nj - 1) * dx + (Z - height_mat[ni + 1][nj - 1]) / (height_mat[ni + 1][nj] - height_mat[ni + 1][nj - 1]) * dx;
					pt.Y = Y0 + (ni + 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni + 1;
					pt.col = nj - 1;
					line.pt.push_back(pt);
					Vk[ni + 1][nj - 1] = 0;
					ni += 1;
					nj -= 1;
				}
				else if (Hk[ni][nj - 1] == 1)
				{
					pt.in = 2;
					pt.X = X0 + (nj - 1) * dx;
					pt.Y = Y0 + ni * dy + dy * (Z - height_mat[ni][nj - 1]) / (height_mat[ni + 1][nj - 1] - height_mat[ni][nj - 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni;
					pt.col = nj - 1;
					line.pt.push_back(pt);
					Hk[ni][nj - 1] = 0;
					nj -= 1;
				}
				else if (Vk[ni][nj - 1] == 1)
				{
					pt.in = 1;
					pt.X = X0 + (nj - 1) * dx + (Z - height_mat[ni][nj - 1]) / (height_mat[ni][nj] - height_mat[ni][nj - 1]) * dx;
					pt.Y = Y0 + (ni)*dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni;
					pt.col = nj - 1;
					line.pt.push_back(pt);
					Vk[ni][nj - 1] = 0;
					nj -= 1;
				}
			}
		}
		else if (pt.in == 1)
		{
			if (ni == 0 || Hk[ni - 1][nj] + Vk[ni - 1][nj] + Hk[ni - 1][nj + 1] == 0)
				break;
			if (Hk[ni - 1][nj] + Vk[ni - 1][nj] + Hk[ni - 1][nj + 1] == 3)
			{
				double zmean = (height_mat[ni - 1][nj] + height_mat[ni - 1][nj + 1] + height_mat[ni][nj] + height_mat[ni][nj + 1]) / 4.0;
				if ((height_mat[ni][nj] - Z) * (zmean - Z) < 0)
				{
					pt.in = 2;
					pt.X = X0 + (nj)*dx;
					pt.Y = Y0 + (ni - 1) * dy + dy * (Z - height_mat[ni - 1][nj]) / (height_mat[ni][nj] - height_mat[ni - 1][nj]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni - 1;
					pt.col = nj;
					line.pt.push_back(pt);
					Hk[ni - 1][nj] = 0;
					ni -= 1;
				}
				else
				{
					pt.in = 4;
					pt.X = X0 + (nj + 1) * dx;
					pt.Y = Y0 + (ni - 1) * dy + dy * (Z - height_mat[ni - 1][nj + 1]) / (height_mat[ni][nj + 1] - height_mat[ni - 1][nj + 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni - 1;
					pt.col = nj + 1;
					line.pt.push_back(pt);
					Hk[ni - 1][nj + 1] = 0;
					ni -= 1;
					nj += 1;
				}
			}
			else
			{
				if (Hk[ni - 1][nj] == 1)
				{
					pt.in = 2;
					pt.X = X0 + (nj)*dx;
					pt.Y = Y0 + (ni - 1) * dy + dy * (Z - height_mat[ni - 1][nj]) / (height_mat[ni][nj] - height_mat[ni - 1][nj]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni - 1;
					pt.col = nj;
					line.pt.push_back(pt);
					Hk[ni - 1][nj] = 0;
					ni -= 1;
				}
				else if (Vk[ni - 1][nj] == 1)
				{
					pt.in = 1;
					pt.X = X0 + nj * dx + (Z - height_mat[ni - 1][nj]) / (height_mat[ni - 1][nj + 1] - height_mat[ni - 1][nj]) * dx;
					pt.Y = Y0 + (ni - 1) * dy;
					pt.Z = Z;
					pt.HK = 1;
					pt.row = ni - 1;
					pt.col = nj;
					line.pt.push_back(pt);
					Vk[ni - 1][nj] = 0;
					ni -= 1;
				}
				else if (Hk[ni - 1][nj + 1] == 1)
				{
					pt.in = 4;
					pt.X = X0 + (nj + 1) * dx;
					pt.Y = Y0 + (ni - 1) * dy + dy * (Z - height_mat[ni - 1][nj + 1]) / (height_mat[ni][nj + 1] - height_mat[ni - 1][nj + 1]);
					pt.Z = Z;
					pt.HK = 0;
					pt.row = ni - 1;
					pt.col = nj + 1;
					line.pt.push_back(pt);
					Hk[ni - 1][nj + 1] = 0;
					ni -= 1;
					nj += 1;
				}
			}
		}
	}
}

void DEM::getline(vector<vector<double>> Hk, vector<vector<double>> Vk, double Z, vector<CLine>& Lines)    //Vk�� Hk��
{
	vector<CLine> Line;
	//�жϿ������� ���к��� 
	//Hk������
	for (int i = 0; i < row - 1; i++)
	{
		if (Hk[i][0] == 1)
		{
			CLine line;
			Hk[i][0] = 0;
			line.shape = 0;
			PtLoc pt;
			pt.X = X0;
			pt.Y = Y0 + i * dy + dy * (Z - height_mat[i][0]) / (height_mat[i + 1][0] - height_mat[i][0]);
			pt.Z = Z;
			pt.in = 4;
			pt.HK = 0;
			pt.row = i;
			pt.col = 0;
			line.pt.push_back(pt);

			//������һ���ȸ��ߵ�
			int ni = i, nj = 0;
			GetlinePt(Hk, Vk, Z, ni, nj, line);
			Line.push_back(line);

		}
	}
	for (int i = 0; i < row - 1; i++)
	{
		if (Hk[i][col - 1] == 1) {
			CLine line;
			Hk[i][col - 1] = 0;
			line.shape = 0;
			PtLoc pt;
			pt.X = X0 + (col - 1) * dx;
			pt.Y = Y0 + i * dy + dy * (Z - height_mat[i][col - 1]) / (height_mat[i + 1][col - 1] - height_mat[i][col - 1]);
			pt.Z = Z;
			pt.in = 2;
			pt.HK = 0;
			pt.row = i;
			pt.col = col - 1;
			line.pt.push_back(pt);

			int ni = i, nj = col - 1;
			GetlinePt(Hk, Vk, Z, ni, nj, line);
			Line.push_back(line);
		}
	}


	//Vk������
	for (int j = 0; j < col - 1; j++)
	{
		if (Vk[0][j] == 1)
		{
			CLine line;
			Vk[0][j] = 0;
			line.shape = 0;
			PtLoc pt;
			pt.X = X0 + j * dx + dx * (Z - height_mat[0][j]) / (height_mat[0][j + 1] - height_mat[0][j]);
			pt.Y = Y0;
			pt.Z = Z;
			pt.in = 3;
			pt.HK = 1;
			pt.row = 0;
			pt.col = j;
			line.pt.push_back(pt);

			//������һ���ȸ��ߵ�
			int ni = 0, nj = j;
			GetlinePt(Hk, Vk, Z, ni, nj, line);
			Line.push_back(line);
		}
	}

	for (int j = 0; j < col - 1; j++)
	{
		if (Vk[row - 1][j] == 1) {
			CLine line;
			Vk[row - 1][j] = 0;
			line.shape = 0;
			PtLoc pt;
			pt.X = X0 + j * dx + dx * (Z - height_mat[row - 1][j]) / (height_mat[row - 1][j + 1] - height_mat[row - 1][j]);
			pt.Y = Y0 + (row - 1) * dy;
			pt.Z = Z;
			pt.in = 1;
			pt.HK = 1;
			pt.row = row - 1;
			pt.col = j;
			line.pt.push_back(pt);

			int ni = row - 1, nj = j;
			GetlinePt(Hk, Vk, Z, ni, nj, line);
			Line.push_back(line);
		}
	}

	//Hk������
	for (int j = col - 1; j >= 0; j--)
	{
		for (int i = 0; i < row - 1; i++)
		{
			if (Hk[i][j] == 1)
			{
				CLine line;
				Hk[i][j] = 1;//�����Ϊ1
				line.shape = 1;//������
				PtLoc pt;
				pt.X = X0 + j * dx;
				pt.Y = Y0 + i * dy + dy * (Z - height_mat[i][j]) / (height_mat[i + 1][j] - height_mat[i][j]);
				pt.Z = Z;
				pt.in = 2;//˳ʱ����ٱ�����
				pt.HK = 0;
				pt.row = i;
				pt.col = j;
				line.pt.push_back(pt);

				int ni = i, nj = j;
				GetlinePt(Hk, Vk, Z, ni, nj, line);
				Line.push_back(line);
			}
		}
	}


	for (int j = col - 2; j >= 0; j--)
	{
		for (int i = 0; i < row; i++)
		{
			if (Vk[i][j] == 1)
			{
				CLine line;
				Vk[i][j] = 1;//�����Ϊ1
				line.shape = 1;//������
				PtLoc pt;
				pt.X = X0 + j * dx + (Z - height_mat[i][j]) / (height_mat[i][j + 1] - height_mat[i][j]) * dx;
				pt.Y = Y0 + i * dy;
				pt.Z = Z;
				pt.in = 1;//niʱ����ٱ�����
				pt.HK = 1;
				pt.row = i;
				pt.col = j;
				line.pt.push_back(pt);

				int ni = i, nj = j;
				GetlinePt(Hk, Vk, Z, ni, nj, line);
				Line.push_back(line);

			}
		}
	}

	///
	for (int i = 0; i < Line.size(); i++)
	{
		if (Line[i].pt.size() < 12)
			Line[i].shape = -1;
	}

	//
	int a = 0;
	for (int n = 0; n < Line.size(); n++)
	{
		CLine l1;
		if (Line[n].shape == 0)
		{
			l1.shape = 0;
			for (int i = 0; i < Line[n].pt.size(); i++)
			{
				a = 0;
				for (int m = 0; m < invalid_val.size(); m++)
				{
					int nr = invalid_val[m].first;
					int nc = invalid_val[m].second;
					if (Line[n].pt[i].HK == 0)
					{
						if ((nr == Line[n].pt[i].row && nc == Line[n].pt[i].col) || (nr == Line[n].pt[i].row + 1 && nc == Line[n].pt[i].col))
							a = 1;
					}
					else
					{
						if ((nr == Line[n].pt[i].row && nc == Line[n].pt[i].col) || (nr == Line[n].pt[i].row && nc == Line[n].pt[i].col + 1))
							a = 1;
					}
				}
				if (a == 0)
					l1.pt.push_back(Line[n].pt[i]);
			}
			Lines.push_back(l1);
		}
		else if (Line[n].shape == 1)
		{
			CLine l2;
			a = 0;
			int b = 0;
			for (int i = 0; i < Line[n].pt.size(); i++)
			{
				b = 0;
				for (int m = 0; m < invalid_val.size(); m++)
				{
					int nr = invalid_val[m].first;
					int nc = invalid_val[m].second;
					if (Line[n].pt[i].HK == 0)
					{
						if ((nr == Line[n].pt[i].row && nc == Line[n].pt[i].col) || (nr == Line[n].pt[i].row + 1 && nc == Line[n].pt[i].col))
						{
							a = 1;
						}
						else
						{
							if (a == 0)
								b = 1;
							else if (a == 1)
								b = 2;
						}
					}
					else
					{
						if ((nr == Line[n].pt[i].row && nc == Line[n].pt[i].col) || (nr == Line[n].pt[i].row && nc == Line[n].pt[i].col + 1))
						{
							a = 1;
						}
						else
						{
							if (a == 0)
								b = 1;
							else if (a == 1)
								b = 2;
						}

					}
				}
				if (b == 1)
					l1.pt.push_back(Line[n].pt[i]);
				else if (b == 2)
					l2.pt.push_back(Line[n].pt[i]);


			}
			if (l2.pt.size() == 0)
			{
				l1.shape = 1;
				Lines.push_back(l1);
			}
			else
			{
				l2.shape = 0;
				l2.pt.insert(l2.pt.end(), l1.pt.begin(), l1.pt.end());
				Lines.push_back(l2);
			}
		}
	}



	/*
	string dir = "../../data/DPEX_Data09/points.txt";
	ofstream outfile(dir);
	double X = 0, Y = 0;
	for (int i = 0; i < 340; i++) {
		for (int j = 0; j < 255; j++) {
			if (Hk[i][j] == 1) {
				X = X0 + j * dx;
				Y = Y0 + i * dy + dy * (Z - height_mat[i][j]) / (height_mat[i + 1][j] - height_mat[i][j]);
				outfile << X << "   " << Y << endl;
			}
		}
	}

	for (int i = 0; i < 341; i++) {
		for (int j = 0; j < 254; j++) {
			if (Vk[i][j] == 1) {
				X = X0 + j * dx + (Z - height_mat[i][j]) / (height_mat[i][j + 1] - height_mat[i][j])*dx;
				Y = Y0 + i * dy;
				outfile << X << "   " << Y << endl;
			}
		}
	}
	outfile.close();*/

}

void DEM::nlines(string dir, double dz)
{
	delz = dz;
	int k = (max_z - min_z) / delz+1;
	//int k = 3;
	for (int i = 1; i <= k; i++)
	{
		vector<vector<double>> Hk;
		vector<vector<double>> Vk;

		double Z = min_z-1+ i * delz;
		Hk = StateMatHk(Z);
		Vk = StateMatVk(Z);
		vector<CLine> Lines;
		getline(Hk, Vk, Z, Lines);
		AllLines.push_back(Lines);
		cout << "The height of "<<Z<<" contour lines have been calculated"<<endl;
	}
	savelines(dir, AllLines);
}

void DEM::savelines(string dir, vector<vector<CLine>> Line)
{
	//Can be opened in QGIS as delimited layer 
	ofstream outfile(dir);
	for (int i = 0; i < Line.size(); i++)
	{
		
		for (int j = 0; j < Line[i].size(); j++)
		{
			outfile <<(i+1)+(i+1)*j<<";" << "LINESTRING(";
			for (int k = 0; k < Line[i][j].pt.size(); k++)
			{
				
				if (Line[i][j].shape > -1)
					outfile<<Line[i][j].pt[k].X << " " << Line[i][j].pt[k].Y << " " << Line[i][j].pt[k].Z << ",";
			}
			outfile << ");" << Line[i][j].pt[0].Z << ";" << endl;
		}
	}
	outfile.close();
}

osg::Node* DEM::Create_DEM(std::string dem_path)
{
	//Set the used space
	osg::ref_ptr<osg::HeightField> heightField = new osg::HeightField();
	heightField->allocate(col, row);			//apply for space
	heightField->setOrigin(osg::Vec3(X0,Y0, 0));			//beginning position
	heightField->setXInterval(dx);			//deltaX
	heightField->setYInterval(dy);			//deltaY
	heightField->setSkirtHeight(1.0f);

	//filled in height value
	for (int r = row - 1; r >= 0; r--)
	{
		for (int c = 0; c < col; c++)
		{
			heightField->setHeight(c, r, height_mat[r][c]);
		}
	}

	//nodes
	osg::Geode* geode = new osg::Geode();
	osg::ref_ptr<osg::ShapeDrawable> heightShape = new osg::ShapeDrawable(heightField.get());
	geode->addDrawable(heightShape);
	int a = AllLines.size();
	for (int i = 0; i < a; i++)
	{
		for (int j = 0; j < AllLines[i].size(); j++)
		{
			osg::ref_ptr<osg::Vec3Array> vex = new osg::Vec3Array;
			for (int k = 0; k < AllLines[i][j].pt.size(); k++) {
				vex->push_back(osg::Vec3(AllLines[i][j].pt[k].X, AllLines[i][j].pt[k].Y, AllLines[i][j].pt[k].Z));
			}
			osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
			geometry->setVertexArray(vex.get());
			////Set the color
			osg::ref_ptr<osg::Vec4Array> colors = new osg::Vec4Array;
			for (int k = 0; k < AllLines[i][j].pt.size(); k++) {
				colors->push_back(osg::Vec4(1.0, 0.5, 0.2, 0.5));
			}
			geometry->setColorArray(colors);
			geometry->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
			osg::ref_ptr<osg::PrimitiveSet> primitiveSet = new osg::DrawArrays(osg::PrimitiveSet::LINE_STRIP, 0, AllLines[i][j].pt.size());
			geometry->addPrimitiveSet(primitiveSet);
			//set line width
			osg::ref_ptr<osg::LineWidth> lw = new osg::LineWidth(1.0);
			geometry->getOrCreateStateSet()->setAttribute(lw, osg::StateAttribute::ON);

			geode->addDrawable(geometry.get());

		}

	}
	osg::ref_ptr<osg::StateSet> stateset = new osg::StateSet();
	geode->setStateSet(stateset.get());

	return geode;
}



int main(int argc, char** argv)
{
	
	string dem_path = "zcor.txt";   //dem file directory, z values inside
	//string dem_path = "rock1.ddem";
	string path = "lines.txt";//output file of isolines, open it in QGIS
	DEM dem(dem_path);
	dem.nlines(path, 2);
	//dem.Interp();
	osgViewer::Viewer viewer;
	osg::Node* model = dem.Create_DEM( dem_path);

	if (model == nullptr)
	{
		printf("ohno");
	}

	viewer.setSceneData(model);
	return viewer.run();

	//return 0;
}

//Test If your OSG works
//#include <osg/ShapeDrawable>
//#include <osg/Texture2D>
//#include <osgViewer/Viewer>
//#include <osgDB/ReadFile>
//
//#include <iostream>
//
//int main(int argc, char** argv)
//{
//	std::cout << "Hello, osg!" << std::endl;
//
//	osg::ref_ptr<osgViewer::Viewer> viewer = new osgViewer::Viewer;
//	viewer->setUpViewInWindow(50, 50, 800, 600);
//	osg::ref_ptr<osg::Geode> geode = new osg::Geode;
//	geode->addDrawable(new osg::ShapeDrawable(new osg::Sphere(osg::Vec3(), 1.0f)));
//	osg::ref_ptr<osg::Texture> texture = new osg::Texture2D(osgDB::readRefImageFile("E:/test/world.png"));
//	auto stateSet = geode->getOrCreateStateSet();
//	stateSet->setTextureAttributeAndModes(0, texture);
//	viewer->setSceneData(geode);
//	return viewer->run();
//}